from setuptools import setup

setup(name='db2xlsx',
      version='0.1',
      description='Convert your *.db file to *.xlsx file',
      packages=['db2xlsx'],
      author_email='saintklovus@gmail.com',
      zip_safe=False)
